import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
} from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';
import { useState } from 'react';
// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  const [result, setResult] = useState(null);
  const [numA, setNumA] = useState('');
  const [numB, setNumB] = useState('');

  const handleCong = () => {
    setResult(numA + numB);
  };
  const handleTru = () => {
    setResult(numA - numB);
  };
  const handleNhan = () => {
    setResult(numA * numB);
  };
  const handleChia = () => {
    if (numB !== 0) {
      setResult(numA / numB);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View>
        <TextInput
          placeholder="số thứ nhất"
          style={{ width: 200, borderWidth: 1, height: 30 }}
          value ={numA}
          onChangeText={(value)=> setNumA(parseInt(value))}
        />
      </View>
      <View>
        <TextInput
          placeholder="số thứ hai"
          style={{ width: 200, borderWidth: 1, height: 30 }}
          value ={numB}
           onChangeText={(value)=> setNumB(parseInt(value))}
        />
      </View>

      <View>
        <Text style={{ width: 200, borderWidth: 1, height: 30 }}>{result} </Text>
      </View>
      <View style={{flex:1,flexDirection:'row'}}>
      <TouchableOpacity style={{ width: 40,height:20,marginLeft:10, backgroundColor: 'green' }} onPress = {handleCong}>
        <Text
          style={{
            fontSize: 12,
            alignSelf: 'center',
            justifyContent: 'center',
            color: '#fff',
          }}>
          Cộng 
        </Text>
      </TouchableOpacity>
      <TouchableOpacity style={{ width: 40,height:20,marginLeft:10, backgroundColor: 'green' }}>
        <Text
          style={{
            fontSize: 12,
            alignSelf: 'center',
            justifyContent: 'center',
            color: '#fff',
          }}>
          Trừ
        </Text>
      </TouchableOpacity>
      <TouchableOpacity style={{ width: 40,height:20,marginLeft:10, backgroundColor: 'green' }}>
        <Text
          style={{
            fontSize: 12,
            alignSelf: 'center',
            justifyContent: 'center',
            color: '#fff',
          }}>
          Nhân
        </Text>
      </TouchableOpacity>
      <TouchableOpacity style={{ width: 40,height:20,marginLeft:10, backgroundColor: 'green' }}>
        <Text
          style={{
            fontSize: 12,
            alignSelf: 'center',
            justifyContent: 'center',
            color: '#fff',
          }}>
          Chia
        </Text>
      </TouchableOpacity>
       <TouchableOpacity style={{ width: 40,height:50 ,backgroundColor: 'green' }}>
        <Text
          style={{
            fontSize: 25,
            alignSelf: 'center',
            justifyContent: 'center',
            color: '#fff',
          }}>
          Xóa
        </Text>
      </TouchableOpacity>
      </View>
     
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  numberStyle: {
    borderWidth: 1,
    padding: 20,
    backgroundColor: '#c3c3c3',
  },
});
